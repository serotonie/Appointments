<pre style="font-size:90%;padding: 0 1em"><code><?php /** @noinspection PhpUndefinedVariableInspection */
echo $_['data'];
?>
</code></pre>